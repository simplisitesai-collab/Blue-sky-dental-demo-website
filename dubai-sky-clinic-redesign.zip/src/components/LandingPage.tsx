import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Phone, 
  Mail, 
  MapPin, 
  Menu, 
  X, 
  ChevronRight, 
  Star, 
  Calendar, 
  Clock, 
  Shield, 
  Users, 
  Award,
  Stethoscope,
  HeartPulse,
  Activity,
  ArrowRight
} from 'lucide-react';

// --- Types ---
interface Service {
  id: number;
  title: string;
  description: string;
  icon: React.ReactNode;
}

interface Doctor {
  id: number;
  name: string;
  specialty: string;
  image: string;
}

interface Testimonial {
  id: number;
  name: string;
  text: string;
  rating: number;
}

// --- Components ---

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled ? 'bg-white/90 backdrop-blur-md py-4 shadow-sm' : 'bg-transparent py-6'}`}>
      <div className="container mx-auto px-6 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-midnight rounded-full flex items-center justify-center">
            <Activity className="text-white w-6 h-6" />
          </div>
          <span className={`text-xl font-serif font-bold tracking-tight ${isScrolled ? 'text-midnight' : 'text-midnight'}`}>
            DUBAI SKY <span className="text-gold">CLINIC</span>
          </span>
        </div>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-8">
          {['Services', 'About', 'Doctors', 'Testimonials'].map((item) => (
            <a 
              key={item} 
              href={`#${item.toLowerCase()}`} 
              className="text-sm font-medium hover:text-gold transition-colors"
            >
              {item}
            </a>
          ))}
          <button className="bg-midnight text-white px-6 py-2.5 rounded-full text-sm font-medium hover:bg-midnight/90 transition-all shadow-md hover:shadow-lg active:scale-95">
            Book Now
          </button>
        </div>

        {/* Mobile Menu Toggle */}
        <button className="md:hidden" onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
          {isMobileMenuOpen ? <X /> : <Menu />}
        </button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="absolute top-full left-0 right-0 bg-white shadow-xl p-6 md:hidden flex flex-col gap-4"
          >
            {['Services', 'About', 'Doctors', 'Testimonials'].map((item) => (
              <a 
                key={item} 
                href={`#${item.toLowerCase()}`} 
                onClick={() => setIsMobileMenuOpen(false)}
                className="text-lg font-medium border-b border-gray-100 pb-2"
              >
                {item}
              </a>
            ))}
            <button className="bg-midnight text-white w-full py-4 rounded-xl font-bold mt-4">
              Book Appointment
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

const Hero = () => {
  return (
    <section className="relative min-h-screen flex items-center pt-20 overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 z-0">
        <div className="absolute top-0 right-0 w-1/2 h-full bg-slate-50 skew-x-[-12deg] translate-x-1/4" />
        <div className="absolute top-1/4 left-10 w-64 h-64 bg-teal-soft/20 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-gold/10 rounded-full blur-3xl" />
      </div>

      <div className="container mx-auto px-6 relative z-10 grid md:grid-cols-2 gap-12 items-center">
        <motion.div
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
        >
          <span className="inline-block px-4 py-1.5 bg-gold/10 text-gold rounded-full text-xs font-bold uppercase tracking-widest mb-6">
            Excellence in Healthcare
          </span>
          <h1 className="text-5xl md:text-7xl font-serif leading-[1.1] mb-6 text-midnight">
            Elevating Your <br />
            <span className="italic text-gold">Health</span> Experience
          </h1>
          <p className="text-lg text-slate-600 mb-10 max-w-lg leading-relaxed">
            Experience world-class medical care in the heart of Dubai. Our multi-specialty clinic combines cutting-edge technology with compassionate expertise.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <button className="bg-midnight text-white px-8 py-4 rounded-full font-bold flex items-center justify-center gap-2 hover:bg-midnight/90 transition-all shadow-xl hover:-translate-y-1">
              Book Appointment <ArrowRight className="w-5 h-5" />
            </button>
            <button className="border border-midnight/20 px-8 py-4 rounded-full font-bold hover:bg-slate-50 transition-all">
              Our Services
            </button>
          </div>

          <div className="mt-12 flex items-center gap-6">
            <div className="flex -space-x-3">
              {[
                'photo-1507003211169-0a1dd7228f2d',
                'photo-1494790108377-be9c29b29330',
                'photo-1500648767791-00dcc994a43e',
                'photo-1573496359142-b8d87734a5a2'
              ].map((id, i) => (
                <img 
                  key={i}
                  src={`https://images.unsplash.com/${id}?auto=format&fit=crop&q=80&w=100&h=100`} 
                  className="w-10 h-10 rounded-full border-2 border-white shadow-sm object-cover"
                  alt="Patient"
                  referrerPolicy="no-referrer"
                />
              ))}
            </div>
            <div>
              <div className="flex text-gold">
                {[1,2,3,4,5].map(i => <Star key={i} className="w-4 h-4 fill-current" />)}
              </div>
              <p className="text-xs font-medium text-slate-500 mt-1">Trusted by 10,000+ patients</p>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, delay: 0.2 }}
          className="relative"
        >
          <div className="relative z-10 rounded-[2rem] overflow-hidden shadow-2xl border-8 border-white">
            <img 
              src="https://images.unsplash.com/photo-1629909613654-28e377c37b09?auto=format&fit=crop&q=80&w=800&h=1000" 
              alt="Modern Clinic Reception" 
              className="w-full h-auto object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
          {/* Floating Stats */}
          <motion.div 
            animate={{ y: [0, -10, 0] }}
            transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            className="absolute -left-10 bottom-20 z-20 glass-card p-6 rounded-2xl flex items-center gap-4"
          >
            <div className="w-12 h-12 bg-gold rounded-xl flex items-center justify-center">
              <Award className="text-white" />
            </div>
            <div>
              <p className="text-2xl font-bold text-midnight">15+</p>
              <p className="text-xs text-slate-500 font-medium">Years Experience</p>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

const Services = () => {
  const services: Service[] = [
    { id: 1, title: 'General Medicine', description: 'Comprehensive health checkups and personalized treatment plans for all ages.', icon: <Stethoscope /> },
    { id: 2, title: 'Cardiology', description: 'Advanced heart care using the latest diagnostic tools and therapeutic techniques.', icon: <HeartPulse /> },
    { id: 3, title: 'Dental Care', description: 'Expert cosmetic and restorative dentistry to keep your smile bright and healthy.', icon: <Activity /> },
    { id: 4, title: 'Dermatology', description: 'Specialized skin treatments for medical conditions and aesthetic enhancements.', icon: <Shield /> },
    { id: 5, title: 'Pediatrics', description: 'Gentle and professional care tailored for the unique needs of children.', icon: <Users /> },
    { id: 6, title: 'Diagnostics', description: 'State-of-the-art laboratory and imaging services for accurate results.', icon: <Clock /> },
  ];

  return (
    <section id="services" className="py-24 bg-slate-50">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-serif mb-4">Our Specialized Services</h2>
          <p className="text-slate-500 max-w-2xl mx-auto">
            We offer a wide range of medical specialties, ensuring that you and your family receive the highest standard of care under one roof.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={service.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ y: -5 }}
              className="bg-white p-8 rounded-3xl shadow-sm hover:shadow-xl transition-all group border border-transparent hover:border-gold/20"
            >
              <div className="w-14 h-14 bg-slate-100 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-gold group-hover:text-white transition-colors">
                {React.cloneElement(service.icon as React.ReactElement, { className: "w-7 h-7" })}
              </div>
              <h3 className="text-xl font-bold mb-3 group-hover:text-gold transition-colors">{service.title}</h3>
              <p className="text-slate-500 leading-relaxed mb-6">
                {service.description}
              </p>
              <a href="#" className="inline-flex items-center gap-2 text-sm font-bold text-midnight hover:gap-3 transition-all">
                Learn More <ChevronRight className="w-4 h-4" />
              </a>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const About = () => {
  return (
    <section id="about" className="py-24 overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="grid md:grid-cols-2 gap-16 items-center">
          <div className="relative">
            <div className="relative z-10 rounded-3xl overflow-hidden shadow-2xl">
              <img 
                src="https://images.unsplash.com/photo-1579684385127-1ef15d508118?auto=format&fit=crop&q=80&w=800&h=800" 
                alt="Doctor consulting with patient" 
                className="w-full h-auto object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="absolute -bottom-10 -right-10 w-64 h-64 bg-gold rounded-3xl -z-0 opacity-10" />
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-[120%] border border-slate-100 rounded-full -z-10" />
          </div>

          <div>
            <span className="text-gold font-bold uppercase tracking-widest text-xs mb-4 block">Why Choose Us</span>
            <h2 className="text-4xl md:text-5xl font-serif mb-8 leading-tight">Committed to Your <br />Health & Well-being</h2>
            <p className="text-slate-600 mb-8 leading-relaxed">
              At Dubai Sky Clinic, we believe that healthcare should be personalized, accessible, and of the highest quality. Our team of international experts is dedicated to providing you with a seamless experience from consultation to recovery.
            </p>

            <div className="space-y-6">
              {[
                { title: 'Expert Specialists', desc: 'Our doctors are board-certified with years of international experience.' },
                { title: 'Modern Technology', desc: 'We invest in the latest medical equipment for precise diagnosis and treatment.' },
                { title: 'Patient-Centric Care', desc: 'Your comfort and health are our top priorities at every step.' }
              ].map((item, i) => (
                <div key={i} className="flex gap-4">
                  <div className="flex-shrink-0 w-6 h-6 rounded-full bg-teal-soft flex items-center justify-center mt-1">
                    <div className="w-2 h-2 bg-midnight rounded-full" />
                  </div>
                  <div>
                    <h4 className="font-bold text-lg mb-1">{item.title}</h4>
                    <p className="text-slate-500 text-sm">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-12 grid grid-cols-3 gap-8 border-t border-slate-100 pt-8">
              <div>
                <p className="text-3xl font-bold text-midnight">98%</p>
                <p className="text-xs text-slate-500 font-medium uppercase tracking-wider">Satisfaction</p>
              </div>
              <div>
                <p className="text-3xl font-bold text-midnight">24/7</p>
                <p className="text-xs text-slate-500 font-medium uppercase tracking-wider">Support</p>
              </div>
              <div>
                <p className="text-3xl font-bold text-midnight">50+</p>
                <p className="text-xs text-slate-500 font-medium uppercase tracking-wider">Specialists</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const Doctors = () => {
  const doctors: Doctor[] = [
    { id: 1, name: 'Dr. Sarah Al-Farsi', specialty: 'Senior Cardiologist', image: 'https://images.unsplash.com/photo-1651008376811-b90baee60c1f?auto=format&fit=crop&q=80&w=400&h=500' },
    { id: 2, name: 'Dr. James Wilson', specialty: 'Orthopedic Surgeon', image: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?auto=format&fit=crop&q=80&w=400&h=500' },
    { id: 3, name: 'Dr. Elena Petrova', specialty: 'Dermatologist', image: 'https://images.unsplash.com/photo-1594824476967-48c8b964273f?auto=format&fit=crop&q=80&w=400&h=500' },
    { id: 4, name: 'Dr. Michael Chen', specialty: 'Pediatrician', image: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&q=80&w=400&h=500' },
  ];

  return (
    <section id="doctors" className="py-24 bg-midnight text-white">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-6">
          <div className="max-w-2xl">
            <span className="text-gold font-bold uppercase tracking-widest text-xs mb-4 block">Our Team</span>
            <h2 className="text-4xl md:text-5xl font-serif">Meet Our World-Class Specialists</h2>
          </div>
          <button className="text-gold font-bold flex items-center gap-2 hover:gap-3 transition-all border-b border-gold/20 pb-1">
            View All Doctors <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {doctors.map((doc, index) => (
            <motion.div
              key={doc.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="group"
            >
              <div className="relative rounded-3xl overflow-hidden aspect-[4/5] mb-6">
                <img 
                  src={doc.image} 
                  alt={doc.name} 
                  className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-500 group-hover:scale-105"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-midnight/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
              <h3 className="text-xl font-bold mb-1">{doc.name}</h3>
              <p className="text-slate-400 text-sm">{doc.specialty}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Testimonials = () => {
  const testimonials: Testimonial[] = [
    { id: 1, name: 'Ahmed Hassan', text: 'The level of care I received at Dubai Sky Clinic was exceptional. The staff is professional and the facilities are top-notch.', rating: 5 },
    { id: 2, name: 'Emily Roberts', text: 'Best dental experience I have ever had. The technology they use is amazing and the results were perfect.', rating: 5 },
    { id: 3, name: 'John Doe', text: 'Very efficient service. I was able to book an appointment quickly and the doctor was very thorough with the examination.', rating: 4 },
  ];

  return (
    <section id="testimonials" className="py-24 bg-slate-50">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-serif mb-4">What Our Patients Say</h2>
          <div className="flex justify-center gap-1 text-gold">
            {[1,2,3,4,5].map(i => <Star key={i} className="w-5 h-5 fill-current" />)}
          </div>
          <p className="text-slate-500 mt-2">4.9/5 Average Patient Rating</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((t, i) => (
            <motion.div
              key={t.id}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="bg-white p-10 rounded-[2.5rem] shadow-sm relative"
            >
              <div className="absolute -top-4 left-10 text-6xl text-gold/20 font-serif">“</div>
              <p className="text-slate-600 italic mb-8 relative z-10">{t.text}</p>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center font-bold text-midnight">
                  {t.name[0]}
                </div>
                <div>
                  <h4 className="font-bold">{t.name}</h4>
                  <div className="flex text-gold">
                    {Array.from({ length: t.rating }).map((_, i) => <Star key={i} className="w-3 h-3 fill-current" />)}
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Footer = () => {
  return (
    <footer className="bg-white pt-24 pb-12 border-t border-slate-100">
      <div className="container mx-auto px-6">
        <div className="grid md:grid-cols-4 gap-12 mb-16">
          <div className="col-span-1 md:col-span-1">
            <div className="flex items-center gap-2 mb-6">
              <div className="w-8 h-8 bg-midnight rounded-full flex items-center justify-center">
                <Activity className="text-white w-5 h-5" />
              </div>
              <span className="text-lg font-serif font-bold tracking-tight">
                DUBAI SKY <span className="text-gold">CLINIC</span>
              </span>
            </div>
            <p className="text-slate-500 text-sm leading-relaxed mb-6">
              Providing premium healthcare services in Dubai with a focus on excellence, innovation, and patient comfort.
            </p>
            <div className="flex gap-4">
              {['fb', 'tw', 'ig', 'li'].map(s => (
                <div key={s} className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-400 hover:bg-midnight hover:text-white transition-all cursor-pointer">
                  <span className="text-[10px] font-bold uppercase">{s}</span>
                </div>
              ))}
            </div>
          </div>

          <div>
            <h4 className="font-bold mb-6">Quick Links</h4>
            <ul className="space-y-4 text-sm text-slate-500">
              <li><a href="#" className="hover:text-gold transition-colors">Find a Doctor</a></li>
              <li><a href="#" className="hover:text-gold transition-colors">Our Services</a></li>
              <li><a href="#" className="hover:text-gold transition-colors">About Us</a></li>
              <li><a href="#" className="hover:text-gold transition-colors">Contact</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold mb-6">Contact Us</h4>
            <ul className="space-y-4 text-sm text-slate-500">
              <li className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-gold flex-shrink-0" />
                <span>Sky Tower, Floor 42, <br />Sheikh Zayed Road, Dubai, UAE</span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-gold flex-shrink-0" />
                <span>+971 4 123 4567</span>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-gold flex-shrink-0" />
                <span>info@dubaiskyclinic.com</span>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold mb-6">Newsletter</h4>
            <p className="text-sm text-slate-500 mb-4">Subscribe to get the latest health tips and news.</p>
            <div className="relative">
              <input 
                type="email" 
                placeholder="Your email" 
                className="w-full bg-slate-50 border border-slate-200 rounded-full py-3 px-6 text-sm focus:outline-none focus:border-gold transition-colors"
              />
              <button className="absolute right-2 top-1/2 -translate-y-1/2 bg-midnight text-white p-2 rounded-full hover:bg-gold transition-colors">
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        <div className="border-t border-slate-100 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-slate-400 font-medium uppercase tracking-widest">
          <p>© 2024 Dubai Sky Clinic. All Rights Reserved.</p>
          <div className="flex gap-8">
            <a href="#" className="hover:text-midnight">Privacy Policy</a>
            <a href="#" className="hover:text-midnight">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default function LandingPage() {
  return (
    <div className="relative">
      <Navbar />
      <Hero />
      <Services />
      <About />
      <Doctors />
      <Testimonials />
      
      {/* Call to Action Section */}
      <section className="py-24">
        <div className="container mx-auto px-6">
          <div className="bg-gold rounded-[3rem] p-12 md:p-20 text-center text-white relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
              <div className="absolute top-0 left-0 w-64 h-64 bg-white rounded-full -translate-x-1/2 -translate-y-1/2" />
              <div className="absolute bottom-0 right-0 w-96 h-96 bg-white rounded-full translate-x-1/3 translate-y-1/3" />
            </div>
            <h2 className="text-4xl md:text-6xl font-serif mb-8 relative z-10">Ready to Prioritize <br />Your Health?</h2>
            <p className="text-white/80 max-w-xl mx-auto mb-10 text-lg relative z-10">
              Book your consultation today and take the first step towards a healthier, happier you.
            </p>
            <button className="bg-white text-gold px-10 py-5 rounded-full font-bold text-lg hover:shadow-2xl transition-all hover:-translate-y-1 active:scale-95 relative z-10">
              Schedule Your Visit
            </button>
          </div>
        </div>
      </section>

      <Footer />

      {/* Floating Action Button */}
      <motion.button 
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        className="fixed bottom-8 right-8 z-40 bg-midnight text-white p-4 rounded-full shadow-2xl flex items-center gap-3 group"
      >
        <Calendar className="w-6 h-6" />
        <span className="max-w-0 overflow-hidden group-hover:max-w-xs transition-all duration-500 font-bold whitespace-nowrap">
          Book Appointment
        </span>
      </motion.button>
    </div>
  );
}
